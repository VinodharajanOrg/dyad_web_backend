import json
import re

def read_input_file(file_path: str):
    with open(file_path, "r") as f:
        return f.read()


def write_output_file(file_path: str, content: str):
    with open(file_path, "w") as f:
        f.write(content)



def write_json(file_path: str, parsed: str):
    with open(file_path, "w") as f:
        # parsed = json.loads(data)
        json.dump(parsed, f, indent=2)


def read_json(file_path: str):
    with open(file_path, "r") as f:
        return json.load(f)
    
# ✅ NEW: Path Derivation Utility
def derive_path(field: str, root="FIDrctDbt"):
    parts = field.strip().split("-")
    return "\\".join([root] + parts)


# ✅ NEW: Bulk Transformation (Table Preprocessing)
def preprocess_table_with_paths(table_data: str, root="FICdtTrf"):
    lines = table_data.strip().split("\n")
    processed_lines = []

    for idx, line in enumerate(lines):
        
        if not line.strip():
            continue


        # Split using multiple spaces or tabs
        columns = re.split(r'\s{2,}|\t+', line.strip())

        if idx == 0 and "target" in columns[1].lower():
            header_line = f"{columns[0]:<30} {columns[1]:<40} {columns[2] if len(columns) > 2 else ''}"
            processed_lines.append(header_line)
            continue


        if len(columns) < 2:
            continue  # skip malformed rows

        target = columns[1]
        source = columns[0] if len(columns) > 1 else ""
        operation = columns[2] if len(columns) > 2 else ""

        # ✅ Apply path derivation ONLY on target
        derived_target = derive_path(target, root)

        # Rebuild row with aligned spacing
        processed_line = f"{source:<30} {derived_target:<40} {operation}"
        processed_lines.append(processed_line)

    return "\n".join(processed_lines)