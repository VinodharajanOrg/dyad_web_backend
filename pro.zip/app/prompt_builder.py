def build_system_prompt():
    return """
        You are a banking transformation engine.

        Your job:
        - Convert tabular mapping data into Trace Transformer XML

        Rules:
        1. Source column = "source"
        2. Target column = "target"
        3. Each row = one FunctionCall
        4. Operation:
        - Single input → Copy
        - Multiple inputs → Concatenate

        RULES FOR context_name:
        1. If a mapping has only ONE source input field:
        - Set context_name = "Input"

        2. If a mapping has MULTIPLE source input fields:
        - Assign sequential names:
            Input1, Input2, Input3, ...
        - Maintain the same order as the source fields and generate in different property if it is comma seperated.

        STRICT XML STRUCTURE:
        MappingDefinition → GroupAction → ActionStep → FunctionCall → Property → Value → NodeSpec → PathNodeSpec

        --------------------------------------------------
        FUNCTION CALL STRUCTURE (STRICT)
        --------------------------------------------------

        Each mapping MUST follow EXACTLY this format:

        <FunctionCall>

            <!-- INPUT PROPERTIES (ONE PER INPUT) -->
            <Property>
                <Value>
                    <NodeSpec>
                        <PathNodeSpec pathString="INPUT_VALUE" specType="FROM_DATA" contextName="Input1"/>
                    </NodeSpec>
                </Value>
            </Property>

            <Property>
                <Value>
                    <NodeSpec>
                        <PathNodeSpec pathString="INPUT_VALUE" specType="FROM_DATA" contextName="Input2"/>
                    </NodeSpec>
                </Value>
            </Property>

            <!-- OUTPUT PROPERTY -->
            <Property name="output">
                <NodeSpec>
                    <PathNodeSpec specType="TO DATA" contextName="Output" path="TARGET_PATH"/>
                </NodeSpec>
            </Property>

            <!-- MAPPER MUST BE LAST -->
            <Mapper>OperationName</Mapper>

        </FunctionCall>


        Rules:
        - Input must include:
        <PathNodeSpec pathString="INPUT_VALUE"  specType="FROM DATA" contextName="InputX" />

        - Output must be:
        <PathNodeSpec pathString="TARGET_PATH"  specType="TO DATA" contextName="Output" />
        
        - FunctionCall name must match operation:
        Copy / Concatenate, Add the Operation value under <Mapper> tag after FunctionCall

        - DO NOT explain anything
        - RETURN ONLY VALID XML
"""

def build_canonical_prompt(table_data: str):
    return f"""
    You are a banking transformation engine.

    Convert the given table into canonical JSON mapping format.

    --------------------------------------------------
    RULES
    --------------------------------------------------

    1. Columns:
    - "message id" → source
    - "CdtInstr/CdtId" → target

    2. Detect operation:
    - Single value → Copy
    - Comma-separated → Concatenate
    - DateTimeNow,<format> → DateTimeToText
    - Static text → CopyText
    - timezone values → ReExpressTimeZone

    3. Detect grouping:
    - Header → non-repeating
    - Iteration → repeating patterns (C1, C2, etc.)

    --------------------------------------------------
    OUTPUT FORMAT (STRICT JSON)
    --------------------------------------------------

    [
    {{
        "operation": "Copy",
        "inputs": ["field1"],
        "output": "A/B/C1"
    }}
    ]

    --------------------------------------------------
    STRICT RULES
    --------------------------------------------------

    - Return ONLY JSON
    - No explanation
    - No comments
    - Ensure valid JSON
    --------------------------------------------------

    Input:
    {table_data}
    """

def build_canonical_prompt1(dto_json: str, table_data: str):
    return f"""
        You are a banking transformation engine.

        Your job:
        Merge DTO structure and mapping entries into canonical JSON.

        --------------------------------------------------
        INPUTS
        --------------------------------------------------

        DTO JSON:
        {dto_json}

        Mapping Table:
        {table_data}

        --------------------------------------------------
        UNDERSTANDING RULES
        --------------------------------------------------

        1. DTO contains:
        - "fields" → HEADER (direct fields)
        - "lists" → ITERATION (repeatable structures)

        2. Mapping table:
        - Left side → target path
        - Right side → source field

        --------------------------------------------------
        CLASSIFICATION LOGIC
        --------------------------------------------------

        - If source field belongs to DTO "fields":
            → classify as HEADER

        - If source field belongs to DTO "lists[].fields":
            → classify as ITERATION

        --------------------------------------------------
        OUTPUT FORMAT (STRICT JSON)
        --------------------------------------------------

        {{
            "header": [
                {{
                    "operation": <operation>,
                    "inputs": [<source>],
                    "output": "<target>"
                }}
            ],
            "iteration": {{
                "collection": <arrayname>,
                "mappings": [
                {{
                    "operation": <operation>,
                    "inputs": [<source>],
                    "output": "<target>"
                }}
                ]
            }}
        }}


        --------------------------------------------------
        RULES
        --------------------------------------------------

        - Detect operation automatically
        - Remove numeric suffix in iteration targets:
        A/B/C1 → A/B/C

        - Only ONE mapping per logical field
        - DO NOT duplicate C1, C2, C3
        - Use loop abstraction

        --------------------------------------------------
        STRICT
        --------------------------------------------------

        - Return ONLY JSON
        - No explanation
        - No comments
        - Ensure valid JSON

        --------------------------------------------------
        """

def build_user_prompt(table_data: str):
    return f"""
        Convert the following table into mapping XML:

        {table_data}
        """

def build_xml_prompt(program: str, version_number: str, build_number: str, timestamp: str, check_sum: str,
                      name:str, group: str,category: str, group_header_desc: str, counter_var: str, repeat_desc: str):
    return f"""
                You are a banking transformation engine.

                Your task:
                Convert canonical JSON mapping into STRICT Trace Transformer XML.

                --------------------------------------------------
                CORE MAPPING RULES
                --------------------------------------------------
                1. Each mapping = one FunctionCall
                2. Source → Property(Input)
                3. Target → Property(Output)
                4. Operation:
                - Single input → Copy
                - Multiple inputs → Concatenate

                --------------------------------------------------
                INPUT PROPERTY RULES
                --------------------------------------------------
                - If ONE input:
                name = "Input"

                - If MULTIPLE inputs:
                name = Input1, Input2, Input3...
                (preserve order)

                --------------------------------------------------
                OUTPUT PROPERTY RULE
                --------------------------------------------------
                - Always:
                name = "Output"

                --------------------------------------------------
                STRICT XML HIERARCHY (MANDATORY)
                --------------------------------------------------
                MappingDefinition
                → GroupAction
                    → ActionStep
                        → FunctionCall
                            → Property
                            → Value
                                → NodeSpec
                                → PathNodeSpec

                --------------------------------------------------
                FUNCTION CALL STRUCTURE (STRICT)
                --------------------------------------------------

                <FunctionCall>

                    <!-- INPUTS -->
                    <Property name="Input1" type="nodespec">
                        <Value>
                            <NodeSpec>
                                <PathNodeSpec specType="FROM_DATA" contextName="Input1" pathString="INPUT_VALUE"/>
                            </NodeSpec>
                        </Value>
                    </Property>

                    <!-- OUTPUT -->
                    <Property name="Output" type="nodespec">
                        <NodeSpec>
                            <PathNodeSpec specType="TO_DATA" contextName="Output" pathString="TARGET_PATH"/>
                        </NodeSpec>
                    </Property>

                    <!-- MAPPER -->
                    <Mapper>Copy</Mapper>

                </FunctionCall>

                --------------------------------------------------
                PATH CONSTRUCTION RULES (CRITICAL)
                --------------------------------------------------

                VALIDATION RULE (MANDATORY):
                --------------------------------------------------
                HEADER RULE (IMPORTANT)
                --------------------------------------------------

                For header mappings:
                - Use input field name directly
                - DO NOT prefix with collection or items

                Example:
                firstName → firstName
                NOT → transactionList/items[apexonValue]/firstName

                Before generating XML, validate every input pathString:

                - It MUST start with <collection>/items[<counter_var>]/
                - If the generated path does NOT follow this format, CORRECT it before output.

                DO NOT output invalid paths.

                Examples:

                Invalid → items[apexonValue]/transactionType  
                Correct → transactionList/items[apexonValue]/transactionType

                Rules:
                1. Use exact array name from DTO
                2. Use literal keyword: items
                3. Use repeatCounter as counter variable
                4. NEVER use raw field name directly inside iteration

                
                For iteration (RepeatAction), ALWAYS construct input pathString as:

                <collection>/items[{counter_var}]/<field_name>
                
                Example:
                transactionList/items[apexonValue]/transactionDate
                
                --------------------------------------------------
                FIELD NORMALIZATION RULES
                --------------------------------------------------

                - snake_case → camelCase
                - Ignore underscores and case differences
                - Match based on semantic meaning

                Examples:
                currency_code → currencyCode
                first_name → firstName

                --------------------------------------------------
                XML TEMPLATE (MANDATORY STRUCTURE)
                --------------------------------------------------

                <MappingDefinition name="{name}" group="{group}" category="{category}">

                    <!-- HEADER -->
                    <ActionStep>
                        <GroupAction>
                            <ActionStep>
                                ...HEADER_FUNCTION_CALL...
                            </ActionStep>
                            <ActionStep>
                                ...HEADER_FUNCTION_CALL...
                            </ActionStep>
                            <Description>{group_header_desc}</Description>
                        </GroupAction>
                    </ActionStep>

                    <!-- ITERATION -->
                    <ActionStep>
                        <GroupAction>
                            <ActionStep>
                                <Description>{repeat_desc}</Description>
                                <ActionComment/>
                            </ActionStep>
                            <ActionStep>
                                <RepeatAction repeatCounter="{counter_var}">
                                    <ActionStep>
                                        ...ITERATION_FUNCTION_CALLS...
                                    </ActionStep>
                                </RepeatAction>
                            </ActionStep>
                        </GroupAction>
                    </ActionStep>

                </MappingDefinition>

                --------------------------------------------------
                STRICT RULES (NO EXCEPTIONS)
                --------------------------------------------------

                - specType must be EXACT:
                FROM_DATA, TO_DATA

                - contextName:
                Input / Input1 / Input2 / ...
                Output

                - Mapper must be LAST inside FunctionCall

                - DO NOT:
                - Add explanations
                - Add extra tags
                - Change structure
                - Skip hierarchy

                --------------------------------------------------
                OUTPUT
                --------------------------------------------------

                Return ONLY valid XML.
                NO explanations.
                NO markdown.
                NO extra text.

        """


def build_user_json_input(canonical_json: str):
    return f"""
        Convert the following table into mapping XML:

        {canonical_json}
        """