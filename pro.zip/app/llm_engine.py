from openai import AzureOpenAI
from app.config import (
    AZURE_OPENAI_API_KEY,
    AZURE_OPENAI_ENDPOINT,
    AZURE_OPENAI_DEPLOYMENT,
    AZURE_OPENAI_API_VERSION,
    XML_BUILD_NO, XML_CATEGORY, XML_CHECK_SUM, XML_COUNTER_VAR, XML_GROUP, XML_GRP_HEADER, XML_NAME, XML_PROGRAM, XML_REPEAT_DESC, XML_TIMESTAMP, XML_VERSION_NO
)
from app.prompt_builder import build_canonical_prompt, build_canonical_prompt1, build_system_prompt, build_user_json_input, build_user_prompt, build_xml_prompt

# Azure client
client = AzureOpenAI(
    api_key=AZURE_OPENAI_API_KEY,
    azure_endpoint=AZURE_OPENAI_ENDPOINT,
    api_version=AZURE_OPENAI_API_VERSION
)



# 🔹 Stage 1: Table → Canonical JSON

def generate_canonical_json1(dto_json: str, table_data: str):
    response = client.chat.completions.create(
        model=AZURE_OPENAI_DEPLOYMENT,
        temperature=0,
        messages=[
            {"role": "system", "content": "You generate standard structured canonical JSON."},
            {"role": "user", "content": build_canonical_prompt1(dto_json, table_data)}
        ]
    )

    return response.choices[0].message.content.strip()

def generate_canonical_json(table_data: str):
    response = client.chat.completions.create(
        model=AZURE_OPENAI_DEPLOYMENT,
        temperature=0,
        messages=[
            {"role": "system", "content": "You generate standard structured canonical JSON."},
            {"role": "user", "content": build_canonical_prompt(table_data)}
        ]
    )

    return response.choices[0].message.content.strip()

def generate_xml(table_data: str):
    system_prompt = build_system_prompt()
    user_prompt = build_user_prompt(table_data)

    response = client.chat.completions.create(
        model=AZURE_OPENAI_DEPLOYMENT,  # deployment name in Azure
        temperature=0,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]
    )

    return response.choices[0].message.content.strip()



# 🔹 Stage 2: Canonical JSON → XML

def generate_xml_from_canonical1(canonical_json: str):
    response = client.chat.completions.create(
        model=AZURE_OPENAI_DEPLOYMENT,
        temperature=0,
        messages=[
            
            {"role": "system", "content": build_xml_prompt(XML_PROGRAM, XML_VERSION_NO, XML_BUILD_NO, XML_TIMESTAMP, XML_CHECK_SUM,
                                                           XML_NAME, XML_GROUP, XML_CATEGORY, XML_GRP_HEADER,
                                                           XML_COUNTER_VAR, XML_REPEAT_DESC)},
            {"role": "user", "content": build_user_json_input(canonical_json)}
        ]
    )

    return response.choices[0].message.content.strip()


def generate_xml_from_canonical(canonical_json: str):
    response = client.chat.completions.create(
        model=AZURE_OPENAI_DEPLOYMENT,
        temperature=0,
        messages=[
            {"role": "system", "content": build_system_prompt()},
            {"role": "user", "content": build_user_json_input(canonical_json)}
        ]
    )

    return response.choices[0].message.content.strip()