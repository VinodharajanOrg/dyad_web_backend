import json

from app.llm_engine import generate_canonical_json, generate_canonical_json1, generate_xml, generate_xml_from_canonical, generate_xml_from_canonical1
from app.validator import validate_xml
from app.utils import preprocess_table_with_paths, read_input_file, read_json, write_json, write_output_file


def run():
    dto_path = "data/dto1.json"
    input_path = "data/sample_input.txt"
    canonical_path = "output/canonical.json"
    output_path = "output/output.xml"

    print("Reading input...")
    dto_json = read_input_file(dto_path)
    table_data = read_input_file(input_path)


    print("Deriving XML Paths from fields...")
    processed_table = preprocess_table_with_paths(table_data)

    print("Processed Table:\n", processed_table)

    print("Generating Canonical JSON...")
    canonical_json_str = generate_canonical_json1(dto_json, processed_table)

    print("Canonical JSON Output:\n", canonical_json_str)

    # Validate JSON
    try:
        parsed_json = json.loads(canonical_json_str)
        write_json(canonical_path, parsed_json)
        print(f"✅ Canonical JSON saved → {canonical_path}")
    except Exception as e:
        print("Invalid Canonical JSON:", e)
        return
    
    
    print("Generating XML using LLM...")
    canonical_json_loaded = json.dumps(read_json(canonical_path))

    xml_output = generate_xml_from_canonical1(canonical_json_loaded)

    print(xml_output)

    print("Validating XML...")
    is_valid, error = validate_xml(xml_output)

    # if not is_valid:
    #     print("❌ XML Validation Failed:", error)
    #     return

    print("Writing output...")
    write_output_file(output_path, xml_output)

    print("XML generated successfully!")
    print(f"📄 Output saved to {output_path}")


if __name__ == "__main__":
    run()