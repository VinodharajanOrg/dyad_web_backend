import os
from dotenv import load_dotenv

load_dotenv()



AZURE_OPENAI_API_KEY = os.getenv("AZURE_OPENAI_API_KEY")
AZURE_OPENAI_ENDPOINT = os.getenv("AZURE_OPENAI_ENDPOINT")
AZURE_OPENAI_DEPLOYMENT = os.getenv("AZURE_OPENAI_DEPLOYMENT")
AZURE_OPENAI_API_VERSION = os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-15-preview")

XML_PROGRAM = os.getenv("xml.program")
XML_VERSION_NO = os.getenv("xml.version_number")
XML_BUILD_NO = os.getenv("xml.build_number")
XML_TIMESTAMP = os.getenv("xml.timestamp")
XML_CHECK_SUM = os.getenv("xml.check_sum")
XML_NAME = os.getenv("xml.name")
XML_GROUP = os.getenv("xml.group")
XML_CATEGORY = os.getenv("xml.category")
XML_GRP_HEADER = os.getenv("xml.group_header_desc")
XML_COUNTER_VAR = os.getenv("xml.counter_var")
XML_REPEAT_DESC = os.getenv("xml.repeat_desc")
