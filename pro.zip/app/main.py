import json

from app.llm_engine import generate_canonical_json, generate_xml, generate_xml_from_canonical
from app.validator import validate_xml
from app.utils import read_input_file, read_json, write_json, write_output_file


def run():
    input_path = "data/sample_input.txt"
    canonical_path = "output/canonical.json"
    output_path = "output/output.xml"

    print("📥 Reading input...")
    table_data = read_input_file(input_path)


    print("🧠 Generating Canonical JSON...")
    canonical_json_str = generate_canonical_json(table_data)

    print("📄 Canonical JSON Output:\n", canonical_json_str)

    # Validate JSON
    try:
        parsed_json = json.loads(canonical_json_str)
        write_json(canonical_path, canonical_json_str)
        print(f"✅ Canonical JSON saved → {canonical_path}")
    except Exception as e:
        print("❌ Invalid Canonical JSON:", e)
        return
    
    
    print("🤖 Generating XML using LLM...")
    canonical_json_loaded = json.dumps(read_json(canonical_path))

    xml_output = generate_xml_from_canonical(canonical_json_loaded)

    print(xml_output)

    print("🛡️ Validating XML...")
    is_valid, error = validate_xml(xml_output)

    if not is_valid:
        print("❌ XML Validation Failed:", error)
        return

    print("💾 Writing output...")
    write_output_file(output_path, xml_output)

    print("✅ XML generated successfully!")
    print(f"📄 Output saved to {output_path}")


if __name__ == "__main__":
    run()