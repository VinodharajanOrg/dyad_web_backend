from lxml import etree


def validate_xml(xml_string: str):
    try:
        etree.fromstring(xml_string.encode("utf-8"))
        return True, None
    except Exception as e:
        return False, str(e)