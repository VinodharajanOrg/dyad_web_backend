import { db } from '../db';
import { settings, languageModelProviders,
  languageModels,} from '../db/schema';
import { eq, ilike } from 'drizzle-orm';
import { AppError } from '../middleware/errorHandler';
import { encryptApiKey, decryptApiKey } from '../utils/crypto';

/**
 * Settings Service - Manages user settings and AI configuration
 */

export interface SelectedModel {
  id: string;
  name: string;
  providerId: string;
}

export interface UserSettings {
  id: number;
  userId: string;
  selectedModel: SelectedModel;
  apiKeys: Record<string, string>;
  selectedChatMode: 'auto-code' | 'agent' | 'ask' | 'custom';
  smartContextEnabled: boolean;
  turboEditsV2Enabled: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export class SettingsService {
  /**
   * Get or create default settings for user
   */
  async getSettings(userId: string = 'default'): Promise<UserSettings> {
    try {
      const [existingSettings] = await db
        .select()
        .from(settings)
        .where(eq(settings.userId, userId))
        .limit(1);

      if (existingSettings) {
        // Decrypt all API keys before returning
        const decryptedKeys: Record<string, string> = {};
        const keys = (existingSettings.apiKeys as Record<string, string>) || {};
        for (const [provider, value] of Object.entries(keys)) {
          decryptedKeys[provider] = value ? decryptApiKey(value) : '';
        }
        return {
          ...existingSettings,
          selectedModel: existingSettings.selectedModel as SelectedModel,
          apiKeys: decryptedKeys,
          selectedChatMode: existingSettings.selectedChatMode as 'auto-code' | 'agent' | 'ask' | 'custom',
        };
      }

      // Create default settings if none exist
      const defaultModel: SelectedModel = {
        id: 'gemini-2.5-pro',
        name: 'Gemini 2.5 Pro',
        providerId: 'google',
      };

      const [newSettings] = await db.insert(settings).values({
        userId,
        selectedModel: defaultModel as any,
        apiKeys: {},
        selectedChatMode: 'auto-code',
        smartContextEnabled: false,
        turboEditsV2Enabled: false,
        createdAt: new Date(),
        updatedAt: new Date(),
      }).returning();

      return {
        ...newSettings,
        selectedModel: newSettings.selectedModel as SelectedModel,
        apiKeys: (newSettings.apiKeys as Record<string, string>) || {},
        selectedChatMode: newSettings.selectedChatMode as 'auto-code' | 'agent' | 'ask' | 'custom',
      };
    } catch (error: any) {
      throw new AppError(500, `Failed to get settings: ${error?.message || String(error)}`);
    }
  }

  /**
   * Update settings
   */
  async updateSettings(
    updates: Partial<{
      selectedModel: SelectedModel;
      apiKeys: Record<string, string>;
      selectedChatMode: string;
      smartContextEnabled: boolean;
      turboEditsV2Enabled: boolean;
    }>,
    userId: string = 'default'
  ): Promise<UserSettings> {
    try {
      // Ensure settings exist
      await this.getSettings(userId);
      const [updated] = await db
        .update(settings)
        .set({
          ...updates,
          updatedAt: new Date(),
        })
        .where(eq(settings.userId, userId))
        .returning();

      if (!updated) {
        throw new AppError(404, 'Settings not found');
      }

      return {
        ...updated,
        selectedModel: updated.selectedModel as SelectedModel,
        apiKeys: (updated.apiKeys as Record<string, string>) || {},
        selectedChatMode: updated.selectedChatMode as 'auto-code' | 'agent' | 'ask' | 'custom',
      };
    } catch (error: any) {
      if (error instanceof AppError) throw error;
      throw new AppError(500, `Failed to update settings: ${error?.message || String(error)}`);
    }
  }

  /**
   * Update API key for a specific provider
   */
  async updateApiKey(providerId: string, apiKey: string, userId: string = 'default'): Promise<UserSettings> {
    try {
      const currentSettings = await this.getSettings(userId);
      // Encrypt the API key before storing
      const updatedKeys = {
        ...currentSettings.apiKeys,
        [providerId]: encryptApiKey(apiKey),
      };
      return await this.updateSettings({ apiKeys: updatedKeys }, userId);
    } catch (error: any) {
      throw new AppError(500, `Failed to update API key: ${error?.message || String(error)}`);
    }
  }

  /**
   * Delete API key for a specific provider
   */
  async deleteApiKey(providerId: string, userId: string = 'default'): Promise<UserSettings> {
    try {
      const currentSettings = await this.getSettings(userId);
      const updatedKeys = { ...currentSettings.apiKeys };
      delete updatedKeys[providerId];

      return await this.updateSettings({ apiKeys: updatedKeys }, userId);
    } catch (error: any) {
      throw new AppError(500, `Failed to delete API key: ${error?.message || String(error)}`);
    }
  }

}