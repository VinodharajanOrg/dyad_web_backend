-- Add api_endpoint column to settings table for custom API endpoints
ALTER TABLE "settings" ADD COLUMN IF NOT EXISTS "api_endpoint" text;
