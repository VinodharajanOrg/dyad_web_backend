-- Create settings table
CREATE TABLE IF NOT EXISTS "settings" (
	"id" serial PRIMARY KEY NOT NULL,
	"user_id" text DEFAULT 'default' NOT NULL,
	"selected_model" jsonb NOT NULL,
	"api_keys" jsonb DEFAULT '{}'::jsonb NOT NULL,
	"selected_chat_mode" text DEFAULT 'auto-code' NOT NULL,
	"smart_context_enabled" boolean DEFAULT false NOT NULL,
	"turbo_edits_v2_enabled" boolean DEFAULT false NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);

-- Create unique index on user_id (for future multi-user support)
CREATE UNIQUE INDEX IF NOT EXISTS "settings_user_id_idx" ON "settings" ("user_id");

-- Insert default settings
INSERT INTO "settings" ("user_id", "selected_model", "api_keys", "selected_chat_mode", "smart_context_enabled", "turbo_edits_v2_enabled")
VALUES (
	'default',
	'{"id": "gpt-4-turbo-preview", "name": "GPT-4 Turbo", "providerId": "openai"}'::jsonb,
	'{}'::jsonb,
	'auto-code',
	false,
	false
)
ON CONFLICT DO NOTHING;
