from decimal import Decimal
from datetime import datetime


class ComparisonValidator:

    def compare(self, json_data: dict, db_data: dict):
        mismatches = []

        for key, json_value in json_data.items():
            db_value = db_data.get(key)

            if not self._values_match(json_value, db_value):
                mismatches.append(
                    {
                        "field": key,
                        "jsonValue": str(json_value),
                        "dbValue": str(db_value),
                        "reason": f"Mismatch in field {key}"
                    }
                )

        return mismatches

    def _values_match(self, json_value, db_value):

        if isinstance(json_value, Decimal):
            return abs(json_value - Decimal(str(db_value))) < Decimal("0.01")

        if isinstance(json_value, datetime):
            return json_value.isoformat() == str(db_value)

        return str(json_value).strip() == str(db_value).strip()