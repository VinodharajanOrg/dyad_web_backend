from app.schemas.transaction_schema import TransactionRequest
from pydantic import ValidationError


def validate_schema(payload: dict):
    try:
        validated = TransactionRequest(**payload)
        return True, validated

    except ValidationError as e:
        return False, e.errors()