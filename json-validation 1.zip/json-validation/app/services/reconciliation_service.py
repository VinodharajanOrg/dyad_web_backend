from app.services.mapping_service import MappingService
from app.validators.comparison_validator import ComparisonValidator
from app.db.repository import fetch_transaction
from app.ai.ai_reasoning import explain_mismatch


mapping_service = MappingService("app/mappings/field_mapping.yaml")
comparison_validator = ComparisonValidator()


class ReconciliationService:

    def process(self, transaction_payload):

        txn_id = transaction_payload["transactionId"]

        db_record = fetch_transaction(txn_id)

        if not db_record:
            return {
                "transactionId": txn_id,
                "status": "FAILED",
                "reason": "Record not found in DB"
            }

        canonical_json = mapping_service.convert_to_canonical(transaction_payload)

        mismatches = comparison_validator.compare(
            canonical_json,
            db_record
        )

        ai_explanations = []

        for mismatch in mismatches:
            explanation = explain_mismatch(mismatch)
            ai_explanations.append(explanation)

        res = {
            "transactionId": txn_id,
            "status": "PASSED" if not mismatches else "FAILED",
            "mismatches": mismatches,
            "aiExplanations": ai_explanations
        }
        print(res)
        return res