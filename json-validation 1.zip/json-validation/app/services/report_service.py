import json
from datetime import datetime


class ReportService:

    def generate_report(self, results):

        file_name = f"/reports/report_{datetime.now().timestamp()}.json"

        with open(file_name, "w") as file:
            json.dump(results, file, indent=4)

        return file_name