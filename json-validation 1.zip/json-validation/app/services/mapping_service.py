import yaml


class MappingService:

    def __init__(self, mapping_file: str):
        with open(mapping_file, "r") as file:
            self.mapping = yaml.safe_load(file)

    def convert_to_canonical(self, payload: dict):
        canonical = {}

        for json_field, db_field in self.mapping.items():
            canonical[db_field] = payload.get(json_field)

        return canonical