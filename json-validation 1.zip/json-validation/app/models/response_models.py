from pydantic import BaseModel
from typing import List


class ValidationErrorModel(BaseModel):
    field: str
    jsonValue: str
    dbValue: str
    reason: str


class ValidationResponse(BaseModel):
    transactionId: str
    status: str
    mismatches: List[ValidationErrorModel]
    aiExplanations: List[str]