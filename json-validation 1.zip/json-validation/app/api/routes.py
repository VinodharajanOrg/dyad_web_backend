from fastapi import APIRouter
from app.validators.schema_validator import validate_schema
from app.services.reconciliation_service import ReconciliationService
from app.services.report_service import ReportService

router = APIRouter()

reconciliation_service = ReconciliationService()
report_service = ReportService()


@router.post("/validate")
def validate_payload(payload: dict):

    valid, response = validate_schema(payload)

    if not valid:
        return {
            "status": "FAILED",
            "schemaErrors": response
        }

    results = []

    for transaction in payload["transactionList"]:
        result = reconciliation_service.process(transaction)
        results.append(result)

    report_path = report_service.generate_report(results)

    return {
        "status": "COMPLETED",
        "report": report_path,
        "results": results
    }