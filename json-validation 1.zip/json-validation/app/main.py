from fastapi import FastAPI
from app.api import routes

app = FastAPI(
    title="AI Validation Platform",
    version="1.0"
)

app.include_router(routes.router)
