from langchain_openai import AzureChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
import os


llm = AzureChatOpenAI(
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
    deployment_name=os.getenv("AZURE_OPENAI_DEPLOYMENT")
)


prompt = ChatPromptTemplate.from_template(
    """
    You are an enterprise validation assistant.

    Explain the mismatch between JSON payload and database values.

    Mismatch:
    {mismatch}

    Provide:
    1. Root cause
    2. Possible business reason
    3. Recommended action
    """
)


def explain_mismatch(mismatch):
    chain = prompt | llm
    response = chain.invoke({"mismatch": mismatch})
    return response.content