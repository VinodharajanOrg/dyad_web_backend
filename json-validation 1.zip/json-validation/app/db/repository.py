from sqlalchemy import text
from app.db.database import SessionLocal


def fetch_transaction(txn_id: str):
    session = SessionLocal()

    query = text(
        """
        SELECT
            txn_id,
            txn_type,
            product_type,
            dr_acc_no,
            cr_acc_no,
            msg_type,
            msg_id,
            created_ts,
            txn_dt,
            txn_amt,
            user_id,
            txn_status,
            remarks,
            txn_count
        FROM transactions
        WHERE txn_id = :txn_id
        """
    )

    result = session.execute(query, {"txn_id": txn_id}).fetchone()

    session.close()

    if result:
        return dict(result._mapping)

    return None