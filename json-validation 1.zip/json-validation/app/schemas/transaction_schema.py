from pydantic import BaseModel
from decimal import Decimal
from datetime import datetime, date
from typing import List


class Transaction(BaseModel):
    transactionId: str
    transactionType: str
    productType: str
    debitAccount: str
    creditAccount: str
    messageType: str
    messageId: str
    creationDate: datetime
    transactionDate: date
    amount: Decimal
    userId: str
    status: str
    message: str
    noOfTransactions: int


class TransactionRequest(BaseModel):
    transactionList: List[Transaction]